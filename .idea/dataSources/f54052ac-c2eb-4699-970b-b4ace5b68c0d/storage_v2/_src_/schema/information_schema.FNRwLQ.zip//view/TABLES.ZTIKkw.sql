create view TABLES as
-- missing source code
;

