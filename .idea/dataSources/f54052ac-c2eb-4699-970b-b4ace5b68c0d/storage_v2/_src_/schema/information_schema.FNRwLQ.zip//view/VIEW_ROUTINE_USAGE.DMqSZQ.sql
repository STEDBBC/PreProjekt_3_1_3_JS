create view VIEW_ROUTINE_USAGE as
-- missing source code
;

