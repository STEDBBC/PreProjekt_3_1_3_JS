create view COLUMN_STATISTICS as
-- missing source code
;

