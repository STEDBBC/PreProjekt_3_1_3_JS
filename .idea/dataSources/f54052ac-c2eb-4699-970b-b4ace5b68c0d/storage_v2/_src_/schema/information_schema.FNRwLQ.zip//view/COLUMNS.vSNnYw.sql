create view COLUMNS as
-- missing source code
;

