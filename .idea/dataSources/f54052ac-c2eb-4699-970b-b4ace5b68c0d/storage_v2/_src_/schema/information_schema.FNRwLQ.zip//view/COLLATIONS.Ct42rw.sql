create view COLLATIONS as
-- missing source code
;

