create view TABLE_CONSTRAINTS_EXTENSIONS as
-- missing source code
;

