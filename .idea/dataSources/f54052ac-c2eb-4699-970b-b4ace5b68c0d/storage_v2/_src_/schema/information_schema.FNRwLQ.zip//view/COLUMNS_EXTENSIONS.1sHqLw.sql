create view COLUMNS_EXTENSIONS as
-- missing source code
;

