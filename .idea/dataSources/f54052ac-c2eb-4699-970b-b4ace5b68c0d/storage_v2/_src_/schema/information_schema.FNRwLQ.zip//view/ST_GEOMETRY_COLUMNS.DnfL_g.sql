create view ST_GEOMETRY_COLUMNS as
-- missing source code
;

