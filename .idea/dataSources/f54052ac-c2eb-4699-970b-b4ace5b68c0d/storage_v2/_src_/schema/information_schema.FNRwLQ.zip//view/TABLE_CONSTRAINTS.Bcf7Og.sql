create view TABLE_CONSTRAINTS as
-- missing source code
;

